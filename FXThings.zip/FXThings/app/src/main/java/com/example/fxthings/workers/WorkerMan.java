package com.example.fxthings.workers;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.fxthings.RatesModel;
import com.example.fxthings.network.NetworkUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class WorkerMan extends Worker {

    private static String TAG = WorkerMan.class.getSimpleName();
    public static String BASE_URL = "https://samples.openweathermap.org/data/2.5/forecast?id=524901&appid=8a547d624aca605f469b238c6718a026";

    private Data outputData;

    public WorkerMan(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.i(TAG, "doWork()");
        getCurrencies();
        return Result.success();
    }

    //Get the JSON data from URL
    public void getCurrencies(){
        List<RatesModel> data = new ArrayList<>();
        URL url = NetworkUtils.buildUrl(BASE_URL);
        String result = null;
        try {
            result = NetworkUtils.getResponseFromHttpUrl(url);

            JSONObject object = new JSONObject(result);
            //Initialize an object of the class House so we can append data to it.
            RatesModel house_data = new RatesModel();
            house_data.temp = object.getInt("message");
            house_data.name = object.getString("cod");
            data.add(house_data);
            outputData = new Data.Builder().putString("data","Passed data from worker").build();
            Log.i("Repo: ", String.valueOf(house_data.temp));

        //System.out.println("Repo results: " + result);
        //JSONArray jArray = new JSONArray(result);

            /*for (int i = 0; i < jArray.length(); i++) {

                //Get objects from the JSONArray.
                JSONObject jsonObject = jArray.getJSONObject(i);

                //Initialize an object of the class House so we can append data to it.
                RatesModel house_data = new RatesModel();

                //Set data to references.
                house_data.temp = jsonObject.getInt("temp");
                house_data.name = jsonObject.getString("pressure");

                //Store the data into an ArrayList.
                data.add(house_data);

                //Post the value(s) of the data to the LiveData Object.
                //listMutableLiveData.postValue(data);
                //outputData = new Data.Builder().putString("data","Passed data from worker").build();
                Log.i("Repo: ", String.valueOf(house_data.temp));
            }*/
        }catch (IOException | NullPointerException | JSONException ioe){
            ioe.printStackTrace();
        }
    }

}
