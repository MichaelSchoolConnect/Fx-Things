package com.example.fxthings.ui.main;

import android.app.Application;

import androidx.arch.core.util.Function;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkContinuation;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import com.example.fxthings.workers.WorkerMan;
import com.example.fxthings.workers.GraphWorker;

import java.util.List;

public class PageViewModel extends ViewModel {

    private WorkManager mWorkManager;
    // The name of the image manipulation work
    static final String WORK_NAME = "image_manipulation_work";

    private String TAG_OUTPUT = "OUTPUT";
    private LiveData<List<WorkInfo>> liveData;


    public void init(Application application) {
        mWorkManager = WorkManager.getInstance(application);
        liveData = mWorkManager.getWorkInfosByTagLiveData(TAG_OUTPUT);
    }

    public void shoot(Application application){
        // Create charging constraint
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        // We want to let the first data sync finish before starting a new one(graph)
        WorkContinuation continuation = mWorkManager
                .beginUniqueWork(WORK_NAME,
                        ExistingWorkPolicy.REPLACE,
                        OneTimeWorkRequest.from(WorkerMan.class));

        OneTimeWorkRequest graph =
                new OneTimeWorkRequest.Builder(GraphWorker.class)
                        .setConstraints(constraints)
                        .addTag(TAG_OUTPUT)
                        .build();

        continuation = continuation.then(graph);

        // Actually start the work
        continuation.enqueue();

    }

    private MutableLiveData<Integer> mIndex = new MutableLiveData<>();
    private LiveData<String> mText = Transformations.map(mIndex, new Function<Integer, String>() {
        @Override
        public String apply(Integer input) {
            return "Hello world from section: " + input;
        }
    });

    public void setIndex(int index) {
        mIndex.setValue(index);
    }

    public LiveData<String> getText() {
        return mText;
    }

    /**
     * Getter method for mSavedWorkInfo
     */
    public LiveData<List<WorkInfo>> getOutputWorkInfo() {
        return liveData;
    }

    /**
     * Cancel work using the work's unique name
     */
    void cancelWork() {
        mWorkManager.cancelUniqueWork(WORK_NAME);
    }
}