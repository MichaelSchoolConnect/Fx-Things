package com.example.fxthings.room.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;

import com.example.fxthings.room.entity.GraphDataEntity;

import java.util.List;

@Dao
public interface DataEntityDao {
    @Transaction
    @Query("SELECT * FROM offlineDataTable")
    LiveData<List<GraphDataEntity>> getAllOfflineData();

    // (onConflict = OnConflictStrategy.REPLACE) = Replace the old data and continue the transaction.
    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOfflineData(GraphDataEntity offlineDataGraphDataEntity);
}
