package com.example.fxthings;


import java.util.ArrayList;
import java.util.List;

public class RatesModel {
    public String name;

    public String cod;

    public double message;

    // The current Objects we use get data via JSON.
    public String data;
    public int temp;

    public RatesModel(){}

    public RatesModel(String data, int temp){
        this.data = data;
        this.temp = temp;
    }

    public String getData() {
        return data;
    }

    public int getTemp() {
        return temp;
    }

    public List<ForecastWeatherData> list = new ArrayList<>();

    public List<MainWeatherData> mainWeatherDataList = new ArrayList<>();

    public static class ForecastWeatherData {

        public Integer id;

        public String main;

        public String description;

    }

    public static class MainWeatherData{

        public int dt;

        public java.lang.Object main;

        public java.lang.Object weather;

        public int temp;

        public int pressure;

        public int humidity;

    }
}
